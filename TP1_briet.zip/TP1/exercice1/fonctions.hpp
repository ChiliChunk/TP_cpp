#include <cstring>

namespace fonctions{

size_t _strlen(const char * str);

void _strcpy (char *destination, const char *source);

char * _strncpy (char *destination, const char *source,size_t num);
}